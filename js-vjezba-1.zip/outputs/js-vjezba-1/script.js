// Primjer 1: JavaScript unutar HTML elementa nalazi se u index.html.
// Ova vanjska datoteka pokazuje povezivanje pomoću <script src="script.js">.

document.getElementById('promijeni-gumb').addEventListener('click', function () {
  document.getElementById('poruka').textContent = 'Tekst je uspješno promijenjen!';
});
