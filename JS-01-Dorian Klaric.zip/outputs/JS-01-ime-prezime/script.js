document.getElementById('poruka-gumb').addEventListener('click', function () {
  alert('Bravo! Uspješno si pokrenuo/la JavaScript poruku.');
});

alert('Vanjska JS datoteka je uspješno povezana!');
